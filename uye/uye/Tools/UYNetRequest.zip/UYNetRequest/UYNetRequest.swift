//
//  UYNetRequest.swift
//  uye
//
//  Created by Tintin on 2017/9/18.
//  Copyright © 2017年 BJZT. All rights reserved.
//

import UIKit


/// 网络请求的类
class UYNetRequest: NSObject {

}
// MARK: - 公共部分
extension UYNetRequest {
    
    func getSafeImageCode(complete:@escaping(_ result:NSDate,_ error:Error?) -> Void) {
        
        let config = UYRequestConfig<UYEmptyModel>()
        config.requestURL = UYRequestAPI.safeCode

        config.parameters = ["":"",
                            "":""]
        UYRequestManager.shared.request(config: config) { (result, error) in
            
        }
    }
}
// MARK: - 登录注册相关
extension UYNetRequest {
    
}

// MARK: - 首页相关
extension UYNetRequest {
    
}

// MARK: - 我的相关
extension UYNetRequest {
    
}


