//
//  UYRequestConfig.swift
//  uye
//
//  Created by Tintin on 2017/9/18.
//  Copyright © 2017年 BJZT. All rights reserved.
//

import UIKit
import Alamofire
import HandyJSON

let UYURLTypeKey = "com.bjzt.base.URL.type"
let DistributionURL = "http://www.baidu.com"
let DevelopmentURL = "http://www.baidu.com"

enum UYDevelopPlatform : Int {
    case Distribution = 0
    case UAT = 1
    case Development = 2
    case Test = 3
}

class UYRequestConfig<T:HandyJSON>: NSObject {
    var requestMethod : HTTPMethod = .post
    var requestURL : UYRequestAPI?
    var parameters : Parameters?
    
  
    
}

// MARK: - 网络请求的API
enum UYRequestAPI : String {//：http://dev.bjzhongteng.com/safe/vcode?w=xx&h=xx
    case login = "app/login" //登录
    case safeCode = "safe/vcode" //获取图形验证码
    
    func requestURLString() -> String {
        return baseURL() + self.rawValue
    }
}

func baseURL() -> String {
    let urlType : UYDevelopPlatform = UYDevelopPlatform(rawValue: UserDefaults.standard.integer(forKey: UYURLTypeKey))!
    switch urlType {
    case .Distribution:
        return DevelopmentURL
    case _ :
        return DistributionURL
    }
}
func updateDevelopPlatform(devPlatform:UYDevelopPlatform) {
    UserDefaults.standard.set(devPlatform, forKey: UYURLTypeKey)
    UserDefaults.standard.synchronize()
}
